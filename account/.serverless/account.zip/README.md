# serverless-crud
Create Serverless crud for Account
